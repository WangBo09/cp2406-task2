# Traffic-Simulator-2.0
### Wang Bo
A GUI based on simulation of traffic.
